 Tic-Tac-Toe AI Agent

This is a simple Python project where I made an **AI that plays Tic-Tac-Toe** against a human. The AI uses a search algorithm to make the best possible moves and is almost impossible to beat.


 Project Objective

To understand the basics of AI decision-making using the **Minimax algorithm**. The goal was to make an agent that can play and never lose in a Tic-Tac-Toe game.


 Tools & Technologies

- Python 3
- Minimax Algorithm
- Alpha-Beta Pruning (for faster move calculation)


## ✅ How to Run

 On Phone (Pydroid 3 or similar):
1. Open the app and paste the code.
2. Tap the Run button ▶️.
3. The game starts and asks for your input.

 On Laptop/PC:
1. Save the file as `tictactoe.py`
2. Double-click it, or right-click → "Open with Python"



